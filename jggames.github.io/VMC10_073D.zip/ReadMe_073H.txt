May 2020 START ===================================
version 0.73H May 23 2020

Welcome to the Virtual MC-10 emulator for Windows 10.

How 0.73G differs from 0.73F:
x Allow other PCM WAV files that aren't 8-bit mono for CLOAD
-- should work with PCM wavs that are 8, 16, 24, 32 mono and stereo
-- Note:  uses only one channel of stereo.  I don't know which.
-- Still does not work with floating point WAVs

x Save Binary
-- save a limited amount of RAM, as a binary file
-- instead of the whole thing.

x Load Last Binary

x When loading binary, you can load LST too
-- You should use script files instead of this...
-- This should work with Load Last Binary too

x Remove Parrot and Baboon from map/level displayer
-- Addition of Color Set Select checkbox

x Change the color of the quarter color blocks on the
-- Keyboard display window.
-- This is an ability your real MC-10 does not have.

Notes:
* Known bug:  All of the bugs reported for 0.73G
* Known bug:  Message box for unsupported WAV types mentions only
-- 8-bit mono supported
* This version has all planned features and should have been
-- labelled "version 1.0"
May 2020 END   ===================================

Sep 2018 START ===================================
version 0.73G September 30 2018

Welcome to the Virtual MC-10 emulator for Windows 10.

How 0.73G differs from 0.73F:
x Write INI files if they don't already exist

x Cosmetic wording of: Load 8K (or 16K) BASIC ROM from file

x toggle menu/statuswindow with right mouse button
-- for making cleaner movies.  Hit right mouse button.
-- Right mouse button again to bring back menu/status

x Sound for cload / csave
-- Turn off ROM Hacks and turn off Speed up files to hear it
-- Recommend NTSC 100% Normal speed.
-- CLOAD of a .C10 does not have gap silences
-- CLOAD of a wav is more realistic* *see what I did there
-- There is a spurious noise at the end
-- The sound quality isn't the same
-- xenoloaders don't work
-- if you know of a pre-existing xenoloader, tell me about it

x Alt L (for Load) starts last CLOADed file

x Alt Q starts last Quicktyped file

x Fill in the Files portion of status bar

x Write dropped files filenames to ini

x removed video slowdown when quicktyping, etc
-- it was causing a spurious video glitch
-- does the glitch happen on a real 6847 ?

Notes:
* the MC-10 does not have an AY-3-8910

* inverse mode remains when Quicktype ends.
-- if you have a problem with that, hit Shift Zero which is INV

* Known bug:  if you have the keyboard display up and switch
    mode to/from Alice4K, the keyboard display will not switch
    and clicking the keys will be wrong.

* Known bug:  All of the bugs reported for 0.73F

Sep 2018 END   ===================================


Aug 2018 START ===================================
version 0.73F August 30 2018

How it differs from 0.73E:
1.  This is the first attempt at splitscreen.
It is not perfect.  Please report suggested fixes.
2.  The default character set has been changed to something more closely resembling the real MC-10's character set.
Many thanks to Ernesto Costa from the 6847 Facebook group for the pictures.
3.  First attempt at Status bar.  Please report bugs.
At present, the status bar shows
Relative speed
Computer emulated (MC-10 or Alice4K)
Memory expander (+16K, +40K, +enh)
I/O (Prn, QT, CasI, CasO, Scr)
4.  Start With by dropping a file onto the program's icon
You can drop a .C10 file or a .TXT file.
VMC-10 will attempt to do the right thing with these.
Important note:
If the TXT file's first character is a #, it will be processed as a SCRIPT file, not a QUICKTYPE.  This has not been tested.
5.  Drag & Drop a single file.
You can drop a .C10 file or a .TXT file onto
the program's window when it is running.
VMC-10 will attempt to do the right thing with these.
Important note:
VMC-10 will NOT automatically reset, to Quicktype a dropped text file.  This allows for merging of... 

Known bugs:
1.  One of the split screen demos is known not to behave the same on the emulator as on the real computer.
2.  The Util>Screenshot does not work with splitscreen.
You may want to use Windows's Alt Printscreen instead.
3.  Still no artifact colors.  This is a holdover from connecting my real MC-10 through my VCR to my Commodore 1084 monitor.  This configuration did not produce artifact colors at all.  Buff was almost white and black was almost black.

Notes:
1.  Needs more testing.  You're a beta tester.  Enjoy.
2.  Under the Help menu, check out the keyboard.
This has worked for several versions.
You can stretch the keyboard display window.
You can click the keys.
You can look at the quarter character graphics which are now more useful than the actual computer's.  We sacrificed realism here for usefulness.  We also helpfully labelled the spacebar.
3.  No, we still do not "mount tape images."
4.  You can change the default colors.
5.  You can't Start With nor Drag & Drop a WAV file.  The reason is that we have don't know whether your WAV is an "exec" or a "run" ahead of time.

Acknowledgements:
1.  You, the viewer.  Thank you.

Aug 2018 END   ===================================


Jul 2017 START ===================================
Version 0.73E, 2017-Jul-14

x Largely untested.  Please test and report bugs
x First Visual Studio 2015 Community version
X Runs under Win10. Not tested even a little bit on other OSes.
X Redo directdraw and directinput
X change the version display to E
X no typing while holding down the ALT key
X change full screen toggle to the more standard ALT ENTER
X fix fullscreen to use more display resolutions
X add config and code to turn off speed display
X dragging window bigger
X allow 6K VRAM

Jul 2017 END   ===================================

May 2012 START ===================================
Version 0.73D, May 8 2012

1. Attempted to fix some overflow flag instructions.
I probably did not get them all, and may not have fixed the ones I tried to fix.
I need to find my power supply for my real MC-10 and write a test program.

2. Attempted to fix loss of keyboard input when the keyboard display (Help / Keyboard) was up.

3. Attempted to add delays to Quicktype.
The "jiffy" mentioned is actually a cpuframe, and will be 1/60th of a second in NTSC unless you've changed the system timing.
The Jiffy ranges are 0-7999 (previous default was 0)
IO timing refers to how many keyboard reads must go by, minimum, while pressing or not pressing a key.
Useful ranges are 1-7999 (previous default was 1)
The most useful thing here is to set the first jiffy delay to 1, set the jiffy delay post return key to ... um... whatever (5 seconds would be 300), and leave the IO waits at 1.

4. Attempted to allow 16K ROM OS.
This does not work with the real MCX128 ROM because VMC-10 does not emulate the other hardware
This does work with the "special" MCX128 ROM image that does not require the real hardware

May 2012 END   ===================================

May 20008 START ===================================
Version 0.73C, May 11 2012
May 20008 END   ===================================

