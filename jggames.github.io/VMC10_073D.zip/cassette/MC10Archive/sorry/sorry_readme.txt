SORRY 20K version
Gary Furr May 1985

Upon execution prevents listing of loaded basic program, by displaying
SORRY in center of screen.
