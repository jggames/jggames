If you're reading this with Notepad, set word wrap to "on."


Quick instructions for Math Design:

These programs are cassette files.  CLOAD them, and then RUN. 

==============

MINICAL (MiniCalc):

You may need to set the emulator to "emulated" keyboard mode.  To do that, from the Config menu select Keyboard.  This brings up the keyboard configuration dialog box.  Check the "Emulated" radio button, and click on "Okay."

(When you're done with MiniCalc, you may want to set the keyboard mode back to "sensible.")

MiniCalc functions like a hand-held calculator.  This was probably the Bee's Knees back in 1983.  Today, you'd just buy a hand-held calculator.

You can perform a few mathematical functions with this program, including:

addition +
subtraction -
division /
multiplication *
sine Control n
cosine Control m
tangent Control ,
log Control .
square root Control /
nth power Control w
integer Control c
absolute value Control b

Conveniently, these calculator functions correspond to the BASIC function keywords printed on the keyboard of a real MC-10 computer.  You DO have a real MC-10, don't you?

If you have typed an incorrect number but have not entered it, press
Control a
once to clear the entry.  Then enter the correct number.  

If you have entered an incorrect number, type
0 ENTER
once or twice until the accumulator shows 0 as the answer.  Then begin your calculation again.

If you have pressed an incorrect mathematical function key + - / *, press the correct function key once or twice until the screen displays it, and continue your calculation.

Quick example:
To do 2 + 2 type
2 ENTER + 2 ENTER

To do 12.3 * 4.5 / 3 type
12.3 ENTER * 4.5 ENTER / 3 ENTER

Now you should have a good idea how to work with the program, and you should also be puzzled about why it requires that you press ENTER after a number but before an operation.  Whoever designed that must have been a doofus.  Unless you're a masochist, you'll then just use the calculator program which came with Windows;  its only big flaw is that the font it uses on its buttons is unreadable, and you can't change the font.


==============

SPIRALS:

This program is designed to work with the MC-10 and the CGP-115 Color Graphic Printer.  Since the emulator does not emulate the CGP-115 Color Graphic Printer, and no printer that hooks up to your Windows PC today will understand CGP-155 Color Graphic Printer commands anyway, you won't find this program to be particularly useful.  It'll just fill up your LPRINT.TXT file with a bunch of meaningless stuff.

Don't believe me?  Run the program, and enter the parameters below.  On a real MC-10 with a CGP-115 printer, it's supposed to print a nice shrinking rotating star.

Number of points = 5
Points per move = 2
Initial rotation = 0
Consecutive rotation = 10
Size ratio = .90
Initial color = 3
Color increment = .25

========

Tape source - James
The digitizing process is never perfect.
Confidence: excellent -- the tape contains two copies of each program.  These all matched.
Oddity: when CLOADed and then CSAVEd out again, the resultant saved file is different from the original, at offsets $91-92-93.  The images here reflect what's on the tape, not what'd be CSAVEd.  *shrug*

