
The programs presented in this directory were
written or edited by talented and dedicated
programmer Charles Pelosi.

This emulator archive has unbundled the programs
from some of their documentation, ancillary files,
file listings, and WAVs.  If you're looking for
those, download the originals at


http://www.geocities.com/chazbeenhad/
Charles Pelosi's MC10 website

mymc10.tripod.com
Mr. Wizard's MC10 website

