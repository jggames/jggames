	document.write('<p align="center">Send a comment to ');
	document.write('<a id="name="SendToJim" name="SendToJim" href="mailto:jimgerrie@ns.sympatico.ca">James Gerrie</a> or ');
	document.write('<a id="name="SendToPatty" name="SendToPatty" href="mailto:pattygerrie@ns.sympatico.ca">Patricia Gerrie</a><br>');
	document.write('Go to <a id="name="homepage" name="homepage" href="http://www3.ns.sympatico.ca/jimgerrie/index.html">James Gerrie&#146;s Home Page</a></p>');
