Turn Word Wrap ON if you're using Notepad.

QUICK TYPE:
===========
How do I get started?

	I like Quicktype better than using CLOAD.  To use Quicktype, write your BASIC program using Notepad.  Save it.  Then use Quicktype from the File menu, and select the file you just saved.  VMC-10 will enter it just as if you had typed it!
	This emulator archive contains several cassette image files (.C10) and several Quicktype text files (.txt).
