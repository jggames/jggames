Turn Word Wrap ON if you're using Notepad.

Virtual MC-10 for Windows95/98, by James the Animal Tamer, emucompboy@yahoo.com

QUICK START:
===========
How do I get started?
	Double click the VMC-10 icon!
	Now you can type your program in.  You can CSAVE it via 
CSAVE "filename"
just as you would if you were using a real MC-10 system.
	You can RUN your program.
	Wow.  Okay.  Suppose you want to load your program back in?  Type CLOAD.  Then from the File menu, select Play Cassette File.  From the dialog box which pops up, select your program!
	Remember, to load, always type CLOAD first, then select the Play Cassette File from the File menu.
	I like Quicktype better than the cassette stuff.  To use Quicktype, write your BASIC program using Notepad.  Save it.  Then use Quicktype from the File menu, and select the file you just saved.  VMC-10 will enter it just as if you had typed it!
	This emulator archive contains several cassette image files (.C10) and several Quicktype text files (.txt).


HOME PAGE:
==========
www.geocities.com/emucompboy
Home of the Virtual Aquarius

CONTACT:
========
emucompboy@yahoo.com

NOTE to ROM IMAGE COLLECTORS:
=============================
Okay, this is a change from my previous policy, so read it!
1.  It's okay to put the emulator archive up for download on your website.  If you do put it up, I ask that you include on your website a link to James the Animal Tamer's Emulators (www.geocities.com/emucompboy), as this emulator's home page.  The emulators are works in progress, and I will randomly be updating them, and not necessarily notifying you about it.
2.  You may not charge money for my work.
3.  You may not include any of my emulators or any of my content on any collection or compilation for which you intend to charge money (unless you plan on sending some money to me, Microsoft, Tandy, Panasonic, and any other relevant copyright or license holders).
4.  I'd prefer that you do not unbundle software or other files that are contained within one of my emulator archives.  That said, I'd be pleased if you make enhanced variants on the computer software and offer those up on your own site.  I'd be MIGHTILY PLEASED if you'd take the "Checkers" or "Calculator" programs from the Virtual MC10 archive, and fix their input to be less retarded.
5.  Oh, please don't link directly to the file names on my site.  I change them with each upate!
Thanks.


System Requirements:
====================
Celeron 400MHz or faster recommended
Windows98 or newer
DirectX 6 or newer
Sound card compatible with DirectX
Fast video card with good appropriate video driver 
Display set to "high color" or "16-bit color" (32768 or 65536 colors) or "True color" or "24 bit color" or "32 bit color"

The emulator will run on slower computers, but probably not at full speed.  The emulator will run with the display settings set to something other than high color, but probably not at full speed, and probably the colors won't look right.  With my Voodoo3 display, the emulator works great in 24-bit and 32-bit modes.  In 256-color mode, it's slow and the colors don't look right.  In 16-color mode, it's really REALLY slow, and the colors look terrible!


Known Bugs
==========
1.  You must configure the printer filename before trying to LPRINT
2.  Some of the interrupts don't work (no one's come up with software that needs 'em)
3.  The implementation of some of the 6803 registers in the $0000-$001F address range is totally fake.  Totally.
4.  Baud rate pokes, and all other aspects of hardware serial I/O, don't work.  Did I mention that the 6803 registers are totally faked?
5.  The sound gets unpleasant overtones at higher frequencies.
6.  It's not finished.  If a feature you need is missing, contact me, emucompboy@yahoo.com
	Winners of the Missing Feature contest for 073a:
	Greg Dionne, many debugger enhancements
	Winners of the Missing Feature contest for 069f:
	Greg Dionne, for pointing out keyboard driver oddity
	Greg Dionne, for providing a list of undocumented ops
		(Doggone it, I have to make these changes to the other emulators too)
	Winners of the Missing Feature contest for 069e:
	Me!  Hey, why not?  I have an enormous ego!  Util PASTE feature.
	Gary Furr, inverse @ power up pattern.
	Previous Winners:
	Me.  Util CSAVEM feature.
	Gary Furr, for pointing out that the sound gets strange at higher frequencies.
		(But I didn't fix it!)
	Gary Furr, for using other filenames that are incompatible with MS-DOS!
	Charles Pelosi, for finding a crash bug (hey, it only crashes on fast computers!)
	Gary Furr, for finding a program which scans the keyboard by walking 1s on the data direction register!
	Gary Furr for digging up docs on a homebrew +40K RAM expander!
	Gary Furr, for his count/compare interrupt driven clock program!  Yay!
	Gary Furr, for putting spaces in his filenames when CSAVEing!


Unknown Bugs
============
1.  Gosh how should I know?  They're unknown, right?  When you find them, contact me, emucompboy@yahoo.com
	Maybe you'll win the Missing Feature contest!


Preliminary Note:
=================
Here's Virtual MC-10 version 0.73a.  The high number indicates that it's fun, useful, and as good an MC-10 emulator as you'll find anywhere, I hope!  Why are you reading this?  Wouldn't you rather be out on a date with Mary-Kate Olsen?

An important feature in this version is Quicktype (from the file menu).  This automatically types a text file.  The best way to use this is to edit a BASIC program as a text file using NOTEPAD.  Save it (from NOTEPAD).  Then use Quicktype to load it into the Virtual MC-10.  This is much easier than trying to type in a program on the Virtual MC-10 itself (although that can be done).

If you simply prefer to use the Virtual MC-10's keyboard, you can later use Quicktype.  LLIST your program, then use NOTEPAD to extract your program from the printer output file.  Save out the extracted program to another text file, and you can use the Quicktype feature to load that in.



What works:
=====================
CPU (instruction set)
Memory (with configuration)
Keyboard (emulated and sensible;  can be configured)
Video, including graphics (Colors can be configured)
Quicktype (provides a means of loading in BASIC programs from text files)
LPRINT/LLIST (To file.)
BASIC CLOAD (C10 files and some WAV files)
BASIC CSAVE (C10 files)
Character set (good but not perfect)
Video border (doesn't quite match the main field, but good enough)
Sound (mostly working)
Accurate timing (close enough)
Window size configuration
Optional loading of other ROM OS
Optional loading of other character set
Utility save for memory as .c10
Full screen mode
Paste from clipboard
Cheap debugger

What does NOT work:
=====================
CPU (microcontroller features)
CPU (undocumented opcodes -- some of them work, but if I told you which ones, then they'd be documented, wouldn't they.)
Timers (working just enough so Sound works)
Interrupts (count/compare works, others don't)
Other peripherals (were there any?) (I'm thinking about doing something for the CGP-115 pen-platen plotter)
Some I/O ports
Serial I/O
Changing of video mode mid-screen
Ordinateur Alice 
Alice 90 arrow keys

What will NEVER work:
=====================
Modem or other RS-232c interface
Any peripheral I can't analyze
Pokemon (sorry, that's for the GAME BOY)


Still left to be done:
======================
Everything that doesn't work
Save WAV files
Drag and drop of supported file types (don't hold your breath)
Better implementation of the top-of-form timer, flag, and interrupt
Have some facility for loading in hex dumps or S-Record files.
CSAVE/CLOAD TPD files (TPD stands for Tape Pulse Data)
Utility save for memory as .bin
Triple check unconnected memory implementation
Printer output sometimes gets garbled
Alice (4K)
Better keyboard configuration
Joystick configuration

NOTES:
=====================
1.  Keyboard.  The keyboard operates in one of two modes:  Emulated or Sensible.  Emulated mode is most like the real MC-10 keyboard;  use this mode for playing games.  Sensible makes it easier to type from the PC keyboard.  You can switch back and forth in the same session.

2.  CLOAD.  To CLOAD a .C10 file from BASIC, first type CLOAD.  Press the Enter key when prompted to type RETURN.  Then select Play Cassette File from the File menu, and choose your .C10 or .WAV cassette file.

3.  Sound.  Uses DirectSound from DirectX6.  It is mostly working.  Known problems include:  The Directsound and CPU emulation are not perfectly in sync, so there can be static.  Note that if your computer is not running the MC-10 emulator at a fairly steady 100%, then the sound won't be right and may have problems.  The sound can be VERY LOUD;  in the Sound Configuration box, the default is 50%.  I recommend you don't make it any louder (I am not responsible for damage to your speakers in any case).

4.  Full Screen.  Uses DirectDraw from DirectX6.  F12 to toggle full screen mode.


Versions:
=========
May 2008:
	0.73c:
	Fixed bizarre loss of keyboard input when LST window was open
April 2008
	0.73b:
	Ordinateur Alice implementation
	Serial joystick for Charlie
	Emulated keyboard display
	Emulated keyboard configuration
March 2008:
	0.73a:
	Debugger
	Attempted implementation of more undocumented opcodes per Greg D.
January 2008
	0.69f:
	Attempted fix for keyboard driver weirdness reported by Greg D.
	Attempted implementation of undocumented opcode 0 per Greg D.
	Bundled more software, and deprecated old versions of some
May 2006
	0.69e:
	Video is now confined to 4K.  The highest resolution modes echo the first 4K.
	Util Paste.
	Loading of K7 multi cassette files (who cares?  there aren't any).
	WAV->CAS logger
	Menus on full-screen (right mouse button toggles).
	Joystick is scanned in parallel with W A S Z and spacebar.
	ROM Hack fast I/O for cassette
March 2005
	0.69c:
	Second attempt at full screen.  F12 toggles full screen.
	Entirely redid clicker sound, double-checked frequency against real MC-10.
		NOTE1:  The sound will reset after menu commands are used,
		or resynchronize after about a half-second of silence.
		NOTE2:  the method used to make sound is much less accurate at
		higher frequencies;  unpleasant overtones become more and more
		obvious.  The real hardware uses a capacitor, which produces
		pleasant tones, but at higher frequencies the sound gets softer.
		Bother.
		NOTE3:  It doesn't sound much like an MC-10 any more.  :(
	Redid some of the timing, to make  the sound work better.
		NOTE1:  I really need to put the emulator on its own thread
		to make this work better.
	First attempt at full screen.  F12 toggles full screen.
	Hooked up F9 hotkey to soft reset.
	Hooked up Shift F9 as hard reset.
	F11 is screenshot.
	Added Util CSAVEM, saves selected moby RAM as .C10 ML tape image file
	Bundled more more software

September 2004
	0.69b:
	Fixes a crash bug, which happens when processing files (e.g. quicktype and cassette) with the "speed up when accessing files" set to on.
	Better implementation of data direction register $0000 in keyscan, fix for mcos program which shifts 1s in data direction register instead of 0s in port.
	Attempt at implementing some of the weirder observations when reading from the keyscan port at locations other than $BFFF.
	Bundling program memwina.txt
	Bundling Telemark Assembler

September 2004
	0.69a:
	Added in the count/compare timer interrupt so Gary Furr's clock program would work.  The fix didn't break the Sound command.  P.S.  MAME's 077s 6800 module has bugs in the resetting of some of flags in register $08.
	CSAVE will now prompt for a filename.
	Added in ability to use external character generator ROM.  Unfortunately, in the MC-10, that's not very useful.  External characters show up only in Alpha/Semigraphics6 mode.
	Added in ability to load OS ROM and character generator ROMs.
	Added Util Load Binary File feature.
	Added Util quick extra Snapshot feature -- puts the screenshots into the screenshots directory.  Beware, the names wrap after 9999.
	unbundled WAV files.  Bundled in tools instead, for converting .C10 to WAV. 
	Fixed some of the cassette image files to match the cassette files, instead of what could be CSAVEd from the emulator.
 	Bundled in other tools.
	Bundled in some programs and documentation looted from other websites.
	

February 21 2002
	0.69:  Changed Quicktype so it could load in lower case as inverse video, and so it could load in the graphic set as well (it's a cheat), thus enabling quicktyping even of such graphic-intense BASIC programs as Checkers.  Swapped out the CPU module for the newer MAME 680x module, for no particular reason.  Fixed an unconnected memory difference which made Pinball's high score not flash correctly.
	Added Math Design and Compac programs.
	Oh, the ability to quicktype lower case as inverse video is configurable from the keyboard configuration box.  You can convert your old text files by unchecking the lower case box, quicktyping your files, and LLISTing them.  Then cut and paste from the LPRINT.TXT file to get your new files.
	Added my picture to the About box.

August 03 2001
	0.68:  Limited ability to load WAV files.  Fixed a bug in CLOAD.  Added more .C10 and instruction files to the archive -- see the subdirectories under /cassette/

September 08 2000:
	0.62:  Sound.  Sound and speed configuration.  Window size configuration.  Fixed cycle timing table, which makes the sound pitch correct, and the CPU speed pretty close.  The MC-10 operates at about 100% clock efficiency!

August 21 2000:
	0.6:  Now on the Internet.


Credits
=======
Me (James the Animal Tamer) -- I put together the emulator, the emulator archive, some docs, some test programs (both .C10 and Quicktype).

6803:	Portable 6803 emulator.  The author isn't mentioned, though his initials are HJB.  (I grabbed this from MAME)

Character set	Drawn by camennie, of the Yahoo MC-10 club

Microsoft	DirectX, Microsoft Visual C++, Microsoft Development Studio, Windows 95/98. 		 Thanks, Bill.

ROMs, cassette images, and Quicktype text files:	See those or their readmes for their respective credits.

The real TRS-80 Microcolor Computer MC-10:	Tandy.  Thanks for making the computer, guys.

Documentation and programs:
	Lifted, looted, and borrowed from many sources, most of whom are active members of the Yahoo MC-10 club!  Here are some of my heroes:

	http://mymc10.tripod.com/
		Mr. Wizard's My MC10 site
		This is the juggernaut of MC-10 sites.
		Lots and lots of software!
		Nice HTML documentation for the Tandy software too!

	http://www.geocities.com/simonsouth/mc10/
		Simon South
		Inside the Radio Shack MC-10

	http://users.bigpond.net.au/jagf/mc10.html
		Gary Furr
		Extended basic

	http://www.neosplice.com/~dsbrain/retro/dl.htm
		Davey Brain
		MC10 documentation in text and HTML format, with pictures
		mc10ref.zip
		mc10refh.zip

	http://groups.yahoo.com/group/trs80mc10club/files/
		File area of the Yahoo! MC-10 club
		MC10-Service-Manual.zip

	http://cocomc10.tripod.com/
		Yet Another MC-10 Page

	http://www.student.cs.uwaterloo.ca/~camennie/mc10/
		disassemblies and memory map
		independent ROM dump

	http://www.gondolin.org.uk/hchof/reviews/yc-mc-10.html
		"your computer" review of the MC-10

	http://www.maltedmedia.com/6803/
		6803 data sheet 

	http://www3.ns.sympatico.ca/jimgerrie/jsoft.html
		(formerly at http://www.hwcn.org/~ar427/jsoft.html)
		Jim Gerrie's software for MC10
		Some good software here, both new and adapted!

	http://www.trs-80.com/trs80-mc.htm
		Ira Goldklang's TRS-80 Revived Pages
		Software here!

	http://www.geocities.com/chazbeenhad/
		Charles Pelosi's MC10 website
		Software here by Charles Pelosi (good stuff!)

	http://www.burgins.com/emulators.html
		PC Dragon version 2.06 -- home of Dragon Convert (dc.exe)

	http://www.dragon-archive-online.co.uk/software/initial.htm
		Instructions for digitizing tape

	http://www.geocities.com/emucompboy
		James the Animal Tamer's Emulators
		Home of the Virtual Aquarius
		Each emulator archive contains an emulator and some software!

	Also google these terms:  TASM and DASMX


Random Jottings
===============
1.  What is an MC-10?
Quick Answer:  A small cheap computer sold at Radio Shacks in the early 1980s.
Longer Answer:  "MC-10" is an abbreviation for "TRS-80 Microcolor Computer MC-10."  Big name for a small computer.  Back in the early 1980s, the British invaded the home computer scene with the Sinclair ZX-81, later marketed by Timex as the TImex-Sinclair 1000.  Several computer companies in America came out with stripped-down inexpensive computers to compete.  The MC-10 was Radio Shack's offering.
	It features a 6803 microcontroller acting as CPU and peripheral interface adapter.  It comes standard with 4K of RAM.  A +16K RAM expander was also sold.  Radio Shack sold a half-dozen or so games on cassette, and a couple of books.
	Gary Furr, author of Extended BASIC and other advanced programs, reports that there was a user group with newsletter.
	Matra & Hachette, a French company, made a French version ("Ordinateur Alice"), then a French version with more memory, then a successor computer whose resemblance to the MC-10 is mostly skin deep ("Alice 32") which was French, and then a French computer reputedly compatible with the Alice 32 but no longer looking like the MC-10 ("Alice 90").

Tangential note:  I have an Alice 32.  At first glance it resembles a red MC-10.  However, screen POKEs from BASIC don't work -- it has a completely different video chip and video memory is not directly accessible by the microprocessor.  It has 16K ROM (twice as much as MC-10), with the new ROM areas apparently containing an assembly language monitor and support for ... a 40-column, 24-line text mode.  Yes, boys and girls, the Alice 32 has a video chip decidedly different from the 6847, the EF9345, and it's French.  See the emulator on my website, or google for the competing emulator DCAlice.

==

2.  What is an emulator?
	An emulator is a software program which enables one computer to act like another.  It'll emulate the graphics, peripherals, sound, timing, etc.  Ideally, the emulator will run pretty much everything the emulated computer could run, and provide a similar "experience."

==

3.  Cool.  Now how do I get started?
	Double click the VMC-10 icon!
	Now you can type your program in.  You can CSAVE it via 
CSAVE "filename"
just as you would if you were using a real MC-10 system.
	You can RUN your program.
	Wow.  Okay.  Suppose you want to load your program back in?  Type CLOAD.  Then from the File menu, select Play Cassette File.  From the dialog box which pops up, select your program!
	Remember, to load, always type CLOAD first, then select the Play Cassette File from the File menu.

	I like Quicktype better than the cassette stuff.  To use Quicktype, write your BASIC program using Notepad.  Save it.  Then use Quicktype from the File menu, and select the file you just saved.  VMC-10 will enter it just as if you had typed it!
	(see the note about lower case under Versions February 21 2002 above).

