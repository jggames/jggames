If you're reading this with Notepad, set word wrap to "on."


Quick instructions for MicroCheckers:

This game is a cassette file.  CLOAD it, and then RUN. 

When you're prompted with FROM? you need to enter a pair of numbers for coordinates (that means enter two numbers separated by a comma).  Here's the board layout:


   1,7   3,7   5,7   7,7
0,6   2,6   4,6   6,6
   1,5   3,5   5,5   7,5
0,4   2,4   4,4   6,4
   1,3   3,3   5,3   7,3
0,2   2,2   4,2   6,2
   1,1   3,1   5,1   7,1
0,0   2,0   4,0   6,0


Enter the TO?  coordinates in the same manner.

Jumping:  Enter the From and To coordinates as usual.  You'll be prompted for another TO coordinate.  If you can jump again, then enter the next To coordinate.  If you can't, then enter -1,-1 to end your move.

To begin a new game, BREAK back to BASIC (the emulator uses the Esc key for BREAK), and RUN again.

========

Tape source - James
The digitizing process is never perfect.
Confidence: excellent -- the tape contains four images of the game.  Two matched.
Oddity: when CLOADed and then CSAVEd out again, the resultant saved file is different from the original, at offsets $91-92-93.  The image here reflects what's on the tape, not what'd be CSAVEd.  *shrug*

