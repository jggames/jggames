Extended Basic by Gary Furr (1986)
----------------------------------
Adds 27 additional BASIC commands to the MC10

Usage:
CLOADM - MC10
CLOADM:EXEC - Emulator

Included in this archive:
ext.bas.wav 747KB - WAV File. Generated using C10TOWAV program
ext.bas.c10 3KB - Emulator file
ExtendedBasic.pdf 26K - Manual
