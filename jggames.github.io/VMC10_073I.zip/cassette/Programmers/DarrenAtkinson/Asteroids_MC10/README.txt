ASTEROIDS  for  MC-10


When playing on a real MC-10 the monochrome graphics
mode used for this game may display random sparkles on
the screen.  This is due to a defect in the design of
the MC-10 hardware.

There is a 50% chance that the problem will occur and
it depends on which edge of the clock the video chip
synchronizes with when the computer is powered on.

You may want to check if the problem will occur before
loading the game.  You can preview the graphics mode
by entering the command:

  POKE 49151,120

If you see a alot of random white pixels moving across
the entire screen then you should turn the computer off
for several seconds and try again.

When the screen is mostly stable (just 2 or 3 rows where
the pixels appear to be changing), press the RESET button
to get back to the normal text screen. Then enter CLOADM
to load the game and EXEC to run it.

