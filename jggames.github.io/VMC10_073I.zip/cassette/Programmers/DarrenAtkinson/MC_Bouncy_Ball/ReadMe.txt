
MC Bouncy Ball for MC-10 is a clone of Lee Patterson's Bouncy Ball
for the CoCo which in turn was inspired by the iOS game Square Ball.


------------------
  COMPATIBILITY
------------------

The game's code along with all twelve levels from the CoCo version are
provided as single .wav and .c10 files.  A 16K RAM expansion (or more)
is needed to run on real hardware.  Use CLOADM and EXEC to load and
run it.

Bouncy Ball has been tailored to run on a real MC-10.  It can also be
played on an emulator or an Alice 4K, but the display will be somewhat
glitchy when scrolling because the game activity and video frame rate
are both driven by a timer running at the 60 Hz NTSC frequency.

When played on real MC-10 hardware you are first presented with a screen
asking you to synchronize the video display with the computer.  Press the
SPACEBAR until the box in the lower portion of the screen is filled with
a green and orange checkerboard.  Once synchronized, press ENTER to start
the game.


------------------
    GAME PLAY
------------------

You are given three lives to complete each level of the game.  If you
lose all three lives on any one level, the game is over.

Each level contains a number of green blocks that can be collected to
score points.  There is a minimum number of these blocks which must be
collected before you can proceed to the Exit.  You also score points
based on how fast you complete the level.

The orange blocks that appear in some levels will be cleared when hit but
do not increase your score.  Hitting a yellow block will cause the ball to
slow down for a couple seconds.

The red blocks are Death Traps which kill you if touched.

You also lose a life if time runs out or if you "Bounce off the world".


------------------
     CONTROLS
------------------

Use either the left/right arrow keys or the '<' and '>' keys for
level selection and game play.

The BREAK key can be used to stop play and return to the level selection
screen.

Press the RESET button to exit the program re-start Basic.



