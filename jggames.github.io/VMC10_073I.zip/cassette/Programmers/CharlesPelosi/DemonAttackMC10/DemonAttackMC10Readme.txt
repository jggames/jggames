Demon Attack MC-10, a TRS-80 MC-10 game.

Object: 

Shoot the pesky demon and get a high score!

Controls:

Use "1" to move left
use "-" to move right
Use "Space Bar" to shoot

Or (for comiled version)

Use "A" to move left
use "D" to move right
Use "Space Bar" to shoot


In the ZIP:

This readme file.
DemonAttackMC10.c10 for use with the emulator Virtual MC-10.
DEMONATTcompiler.c10 compiled using Greg Dionne's MCBASIC compiler,
with edits by Jim Gerrie 2021

Links:

Charlie�s TRS-80 MC-10 web page: www.geocities.com/chazbeenhad
Yahoo MC-10 group: http://groups.yahoo.com/group/trs80mc10club/
Virtual MC-10: http://www.geocities.com/emucompboy/

5/20/04 chazbeenhad@hotmail.com
12/19/21 jimgerrie@sympatico.ca
