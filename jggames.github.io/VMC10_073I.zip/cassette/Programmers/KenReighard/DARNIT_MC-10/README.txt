In what can best be described as a fit of insanity, I ported my solitaire game Darn It! to the MC-10. If the emulator can be believed, it will fit into an original 4K MC-10. It will also work on a Color Computer 1 and 2. I have enclosed the DARNIT.C10 file for the MC-10 and a DARNIT.DSK file for the Color Computer 1 & 2.

Darn It

This solitaire card game appeared in the January 1993 issue of The Rainbow. It was respired by a solitaire game from a PC at college that I somewhat remembered the rules of play. This MC-10 port was created in February 2018.

In Darn It, six columns of six cards each are displayed face up in the upper portion of the screen. The rest of the deck ( 16 cards) are placed face down in the lower-left area, and the top card of this deck is turned face up on the right. This latter card is the �play'' pile.

The object of Darn It is to move all the cards from the top portion of the screen to the play pile. Legal moves are chose in which the card to be played has a value exactly one higher or lower than the value of the face-up card at the top of the play pile. The suit of the cards is irrelevant. The card values go from Ace (low) to King (high).  Use the J and L keys to select a column and the I key to play the card from that column. When none of the bottom cards in the column can be played, turn the next card on the deck face up on the play pile with the K key. The number of cards remaining in the deck is indicated on the back of the deck. When the deck is empty and no legal move are left, the game is over. 

You can go back in the game using the �UNDO� key (�U�) to undo moves. You can go all the way back to the beginning and try a new strategy. 

This is the version with bug correction 2018-02-25.

